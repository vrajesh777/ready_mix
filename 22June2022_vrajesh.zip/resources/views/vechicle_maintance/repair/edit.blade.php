@extends('layout.master')
@section('main_content')

@php
	$count = isset($arr_data['vhc_part_detail'])?count($arr_data['vhc_part_detail']):0;
@endphp
<form method="POST" action="{{ Route('vhc_repair_update',$enc_id) }}" id="formAddUser" enctype="multipart/form-data">
{{ csrf_field() }}
	<div class="row">
		<div class="col-sm-12">

			@include('layout._operation_status')

			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-sm-3">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.vehicle') }} <span class="text-danger">*</span></label>
	                            <select name="vechicle_id" class="select2" id="vechicle_id" data-rule-required="true" disabled>
									<option value="">{{ trans('admin.select') }} {{ trans('admin.vehicle') }}</option>
									@if(isset($arr_vechicle) && sizeof($arr_vechicle)>0)
										@foreach($arr_vechicle as $vechicle)
											<option value="{{ $vechicle['id'] ?? '' }}" @if(isset($arr_data['vechicle_id']) && $arr_data['vechicle_id']!='' && $arr_data['vechicle_id'] == $vechicle['id']) selected @endif>{{ $vechicle['name'] ?? '' }}</option>
										@endforeach
									@endif
								</select>
								<div class="error">{{ $errors->first('vechicle_id') }}</div>
	    					</div>
						</div>
						<input type="hidden" name="vechicle_id" value="{{ $arr_data['vechicle_id'] ?? 0 }}">
						<div class="col-sm-3">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.assignee') }} <span class="text-danger">*</span></label>
	                            <select name="assignee_id" class="select2" id="assignee_id" data-rule-required="true" disabled>
									<option value="">{{ trans('admin.select') }} {{ trans('admin.assignee') }}</option>
									@if(isset($arr_mechanics) && sizeof($arr_mechanics)>0)
										@foreach($arr_mechanics as $mechanic)
											<option value="{{ $mechanic['id'] ?? '' }}" @if(isset($arr_data['assignee_id']) && $arr_data['assignee_id']!='' && $arr_data['assignee_id'] == $mechanic['id']) selected @endif>
												@if(\App::getLocale() == 'ar')
													<span>{{ $mechanic['first_name'] ?? '' }}</span>
												@else
													<span> {{ $mechanic['last_name'] ?? '' }}</span>
												@endif
											</option>
										@endforeach
									@endif
								</select>
								<div class="error">{{ $errors->first('vechicle_id') }}</div>
	    					</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.delivery_date') }}<span class="text-danger">*</span></label>
	                            <input class="form-control datepicker pr-5" name="delivery_date" value="{{ $arr_data['delivery_date'] ?? '' }}" id="delivery_date" data-rule-required="true" placeholder="Date" autocomplete="off">
								<div class="error">{{ $errors->first('delivery_date') }}</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.time') }}<span class="text-danger">*</span></label>
	                            <input class="form-control timepicker pr-5" name="time" value="{{ $arr_data['time'] ?? '' }}" id="delivery_time" data-rule-required="true" placeholder="HH:mm" autocomplete="off">
								<div class="error">{{ $errors->first('time') }}</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.door_no') }}<span class="text-danger">*</span></label>
	                            <input type="text" name="door_no" value="{{ $arr_data['door_no'] ?? '' }}" data-rule-required="true" class="form-control" disabled>
	                            <div class="error">{{ $errors->first('door_no') }}</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.km_count') }}<span class="text-danger">*</span></label>
	                            <input type="text" name="km_count" value="{{ $arr_data['km_count'] ?? '' }}" data-rule-required="true" class="form-control" disabled>
	                            <div class="error">{{ $errors->first('km_count') }}</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.hours_meter') }}<span class="text-danger">*</span></label>
	                            <input type="text" name="hours_meter" value="{{ $arr_data['hours_meter'] ?? '' }}" data-rule-required="true" class="form-control">
	                            <div class="error">{{ $errors->first('hours_meter') }}</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.complaint') }}<span class="text-danger">*</span></label>
	                            <textarea name="complaint" value="{{ $arr_data['complaint'] ?? '' }}" data-rule-required="true" class="form-control" value="{{ date('Y-m-d') }}" disabled>{{ $arr_data['complaint'] ?? '' }}</textarea>
	                            <div class="error">{{ $errors->first('complaint') }}</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.diagnosis') }}<span class="text-danger">*</span></label>
	                            <textarea name="diagnosis" value="{{ $arr_data['diagnosis'] ?? '' }}" data-rule-required="true" class="form-control" value="{{ date('Y-m-d') }}" disabled>{{ $arr_data['diagnosis'] ?? '' }}</textarea>
	                            <div class="error">{{ $errors->first('diagnosis') }}</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.actions') }} <span class="text-danger">*</span></label>
	                            <textarea class="form-control" name="action" value="{{ $arr_data['action'] ?? '' }}" data-rule-required="true" disabled>{{ $arr_data['action'] ?? '' }}</textarea>
	                            <div class="error">{{ $errors->first('action') }}</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.note') }} <span class="text-danger">*</span></label>
	                            <textarea class="form-control" name="note" value="{{ $arr_data['note'] ?? '' }}" data-rule-required="true" disabled>{{ $arr_data['note'] ?? '' }}</textarea>
	                            <div class="error">{{ $errors->first('note') }}</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label class="col-form-label">{{ trans('admin.remark') }} <span class="text-danger">*</span></label>
	                            <textarea class="form-control" name="remark" value="{{ $arr_data['remark'] ?? '' }}" data-rule-required="true">{{ $arr_data['remark'] ?? '' }}</textarea>
	                            <div class="error">{{ $errors->first('remark') }}</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row" id="vhc_details">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<h4><i class="fa fa-car"></i> {{ trans('admin.vehicle') }} {{ trans('admin.details') }}</h4>
					<div class="row">
						<div class="col-sm-3">
							{{ trans('admin.vehicle') }} {{ trans('admin.name') }} : <span id="vehicle_name"></span>
						</div>
						<div class="col-sm-3">
							{{ trans('admin.make') }} : <span id="make"></span>
						</div>
						<div class="col-sm-3">
							{{ trans('admin.model') }} : <span id="model"></span>
						</div>
						<div class="col-sm-3">
							{{ trans('admin.year') }} : <span id="year"></span>
						</div>
						<div class="col-sm-3">
							{{ trans('admin.chasis_no') }} : <span id="chasis_no"></span>
						</div>
						<div class="col-sm-3">
							{{ trans('admin.vin_no') }}# : <span id="vin_no"></span>
						</div>
						<div class="col-sm-3">
							{{ trans('admin.registration_no') }} : <span id="reg_no"></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<h4><i class="fa fa-wrench"></i> {{ trans('admin.add') }} {{ trans('admin.parts') }}</h4>
					<div class="row">
						<table id="partsdata" class="table table-bordered">
							<thead>
								<tr>
									<th>{{ trans('admin.make') }}</th>
									<th>{{ trans('admin.model') }}</th>
									<th>{{ trans('admin.year') }}</th>
									<th>{{ trans('admin.parts') }}</th>
									<th>{{ trans('admin.qty') }}</th>
									<th>{{ trans('admin.yes') }}</th>
									<th></th>
								</tr>
							</thead>
							<tfoot>
				                @if(isset($arr_data['vhc_part_detail']) && sizeof($arr_data['vhc_part_detail'])>0)
								@foreach($arr_data['vhc_part_detail'] as $p_key => $p_val)
									<tbody id='parts-row{{ $p_key ?? 0 }}'>
										<tr>
											<td class='left'>
												<select class='form-control' id="make_{{ $p_key ?? 0 }}" onchange='loadModelDatax(this,{{ $p_key ?? 0 }});' name='partsfilter[{{ $p_key ?? 0 }}][make]'>
													<option value=''>--Select Make--</option>
													@if(isset($arr_make) && sizeof($arr_make)>0)
														@foreach($arr_make as $make)
															<option value="{{ $make['id'] ?? 0 }}" @if($make['id'] == $p_val['make_id']) selected @endif>{{ $make['make_name'] ?? 0 }}</option>
														@endforeach
													@endif
												</select>
											</td>
											<td class='left'>
												<select class='form-control' onchange='loadYearDatax(this,{{ $p_key ?? 0 }});' name='partsfilter[{{ $p_key ?? 0 }}][model]' id='model_{{ $p_key ?? 0 }}'>
													<option value=''>--Select Model--</option>
													@if(isset($arr_model) && sizeof($arr_model)>0)
														@foreach($arr_model as $model)
															@if($model['make_id'] == $p_val['make_id'])
																<option value="{{ $model['id'] ?? 0 }}" @if($model['id'] == $p_val['model_id']) selected @endif>{{ $model['model_name'] ?? 0 }}</option>
															@endif
														@endforeach
													@endif
												</select>
											</td>
											@php
												$yearArray = [];
												$start = get_year_from_model_make($p_val['make_id'],$p_val['model_id']);
												if($start!='')
												{
													$end = date('Y');
								                	$yearArray = range($start,$end);
												}
											@endphp
											<td class='left'>
												<select class='form-control' name='partsfilter[{{ $p_key ?? 0 }}][year]' id='year_{{ $p_key ?? 0 }}'>
													<option value=''>--Select Year--</option>
													
													@if(isset($yearArray) && sizeof($yearArray)>0)
														@foreach($yearArray as $year)
															{{-- @if($year['id'] == $p_val['year_id']) --}}
																<option value="{{ $year ?? 0 }}" @if($year == $p_val['year_id']) selected @endif>{{ $year ?? 0 }}</option>
															{{-- @endif --}}
														@endforeach
													@endif
												</select>
											</td>

											

											<td class="left">
												<select class="form-control" id="part_{{ $p_key ?? 0 }}" name="partsfilter[{{ $p_key ?? 0 }}][part]">
													<option value="">--Select Part--</option>
													@if(isset($arr_parts) && sizeof($arr_parts)>0)
														@foreach($arr_parts as $part)
															 @if(($part['make_id'] == $p_val['make_id']) && ($part['model_id'] == $p_val['model_id']))
																<option value="{{ $part['part_id'] ?? 0 }}" @if($part['part_id'] == $p_val['part_id']) selected @endif>{{ $part['part']['commodity_name'] ?? 0 }}</option>
															@endif
														@endforeach
													@endif
												</select>
											</td>

											<td class="text-right"><input id="qty_{{ $p_key ?? 0 }}" type="text" name="partsfilter[{{ $p_key ?? 0 }}][quantity]" class="form-control" value="{{ $p_val['quantity'] ?? 0 }}" /></td>
											<td class="text-right"><input id="received_{{ $p_key ?? 0 }}" type="checkbox" 
												 name="partsfilter[{{ $p_key ?? 0 }}][received]" class="form-control decrement_repair_stock" data-toggle="tooltip" data-placement="top" title="Recevied" style="width: 20px;"  /></td>
											<td class='left'>
												<button class='btn btn-danger' title='Remove' data-toggle='tooltip' onclick="$( '#parts-row{{ $p_key ?? 0 }}').remove()"; type='button'><i class='fa fa-minus-circle'></i></button>
											</td>
										</tr>
									</tbody>
								@endforeach
								@endif

				                <tr>
				                  	<td colspan="6"></td>
				                  	<td class="left"><button class="btn btn-primary" title="" data-toggle="tooltip" onclick="addPartsData();" type="button"><i class="fa fa-plus-circle"></i></button></td>
				                </tr>
				            </tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="text-center py-3 w-100">
    	<button type="submit" class="border-0 btn btn-primary btn-gradient-primary btn-rounded">{{ trans('admin.save') }}</button>&nbsp;&nbsp;
    	<button type="button" class="btn btn-secondary btn-rounded">{{ trans('admin.cancel') }}</button>
    </div>
</form>
<!-- /Page Header -->
<script src="{{ asset('/js/moment.min.js') }}"></script>
<script src="{{ asset('/js/bootstrap-datetimepicker.min.js') }}"></script>

<script type="text/javascript">

	$(document).ready(function() {

		initiate_form_validate();

		$('.select2').select2();

		$( '#delivery_date' ).datepicker({
			format:'yyyy-mm-dd',
			autoclose: true,
			startDate: "dateToday",
		});
		
		$('.timepicker').datetimepicker({
			format : 'HH:mm'
        });
		var vhc_id = $('#vechicle_id').val();
		vechicle_details(vhc_id);
		$('.decrement_repair_stock').change(function(){
			let isChecked = $(this).is(':checked');
			decrementRepairStockCall(vhc_id,isChecked)
		})
	});

	function vechicle_details(vhc_id)
	{
		$.ajax({
					url:"{{ Route('vechicle_details','') }}/"+btoa(vhc_id),
					type:'GET',
					dataType:'json',
					success:function(resp){

						if(resp.status == 'success')
						{
							if(typeof(resp.arr_vechicle) == 'object')
							{
								$('#vhc_details').show();
								$('#vehicle_name').html(resp.arr_vechicle.name);
								$('#make').html(resp.arr_vechicle.make.make_name);
								$('#model').html(resp.arr_vechicle.model.model_name);
								$('#year').html(resp.arr_vechicle.year.year);
								$('#chasis_no').html(resp.arr_vechicle.chasis_no);
								$('#vin_no').html(resp.arr_vechicle.vin_no);
								$('#reg_no').html(resp.arr_vechicle.regs_no);
							}
						}

					}
			});
	}


	function initiate_form_validate() {
		$('#formAddUser').validate({
			ignore: [],
			errorPlacement: function (error, element) {
			    if(element.hasClass('select2') && element.next('.select2-container').length) {
			        error.insertAfter(element.next('.select2-container'));
			    }else if (element.parent('.input-group').length) {
		            error.insertAfter(element.parent());
		        }
		        else if (element.prop('type') === 'radio' && element.parent('.radio-inline').length) {
		            error.insertAfter(element.parent().parent());
		        }
		        else if (element.prop('type') === 'checkbox' || element.prop('type') === 'radio') {
		            error.appendTo(element.parent().parent());
		        }
		        else {
		            error.insertAfter(element);
		        }
			}
		});
	}

	var arr_make = <?php echo json_encode($arr_make); ?>;
	var parts_rows = "{{ $count ?? 0 }}";
	function addPartsData() {
		console.log(arr_make);

		var makeOption = '<option value="">{{ trans('admin.select') }}  {{ trans('admin.model') }} </option>'; 
		if(typeof(arr_make) == 'object')
		{
			$(arr_make).each(function(index,make){
				makeOption+='<option value="'+make.id+'">'+make.make_name+'</option>';
			})
		}

		html  = '<tbody id="parts-row' + parts_rows + '">';
		html += '  <tr>';
		html += '    <td class="left"><select class="form-control" id="make_' + parts_rows + '" name="partsfilter[' + parts_rows + '][make]" onchange="loadModelDatax(this,' + parts_rows + ');">';
		html += makeOption;
		html += '    </td>';

		html += '    <td class="left"><select class="form-control" disabled="disabled" id="model_' + parts_rows + '" name="partsfilter[' + parts_rows + '][model]" onchange="loadYearDatax(this,' + parts_rows + ');">';
		html += '      <option value="">--{{ trans('admin.select') }}  {{ trans('admin.model') }} --</option>';
		html += '    </select></td>';

		html += '    <td class="left"><select class="form-control" id="year_' + parts_rows + '" disabled="disabled" name="partsfilter[' + parts_rows + '][year]" onchange="loadPartxDatax(this,' + parts_rows + ');">';
		html += '      <option value="">--{{ trans('admin.select') }}  {{ trans('admin.year') }}--</option>';
		html += '    </select></td>';

		html += '    <td class="left"><select class="form-control" id="part_' + parts_rows + '" disabled="disabled" name="partsfilter[' + parts_rows + '][part]">';
		html += '      <option value="">--{{ trans('admin.select') }}  {{ trans('admin.part') }}--</option>';
		html += '    </select></td>';

		html += '  <td class="text-right"><input id="qty_' + parts_rows + '" type="text" name="partsfilter[' + parts_rows + '][quantity]" class="form-control" /></td>';

		html += '    <td class="left"><button class="btn btn-danger" title="Remove" data-toggle="tooltip" onclick="$(\'#parts-row' + parts_rows + '\').remove();" type="button"><i class="fa fa-minus-circle"></i></button></td>';
		html += '  </tr>';	
		html += '</tbody>';
		
		$('#partsdata tfoot').before(html);
		
		parts_rows++;
	}

	function loadModelDatax(obj,row){
		if(obj.value != ''){
			$.ajax({
				type: "GET",
				url: '{{ Route('get_model_html','') }}/'+obj.value,
				success: function(response) {
					if(response.status == 'success'){
						$("#model_" + row).html(response.data);
						$("#model_" + row).prop('disabled', false);
					}
					else{
						alert('Wrong Request');
						$("#model_" + row).prop('disabled', true);
					}
				},
			});
		}
	}

	function loadYearDatax(obj,row){
		if(obj.value != ''){
			var post_url = '{{ Route('get_year_html') }}'+'?model_id='+obj.value+'&make_id='+$("#make_" + row).val();
			$.ajax({
				type: "GET",
				url: post_url,
				success: function(response) {
					if(response.status == 'success'){
						$("#year_" + row).html(response.data);
						$("#year_" + row).prop('disabled', false);
					}
					else{
						alert('Wrong Request');
						$("#year_" + row).prop('disabled', true);
					}
				},
			});
		}
	}

	function loadPartxDatax(obj,row){
		if(obj.value != ''){
			var post_url = '{{ Route('get_parts_html') }}'+'?model_id='+$("#model_" + row).val()+'&make_id='+$("#make_" + row).val()+'&year_id='+$("#year_" + row).val();
			$.ajax({
				type: "GET",
				url: post_url,
				success: function(response) {
					if(response.status == 'success'){
						$("#part_" + row).html(response.data);
						$("#part_" + row).prop('disabled', false);
					}
					else{
						$("#part_" + row).prop('disabled', true);
					}
				},
			});
		}
	}
	// decrement repair stock
	function decrementRepairStockCall(vhc_id,isChecked)
	{
		// console.log($(this))
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
		
		$.ajax({
			url:"{{ Route('decrement_repair_stock','') }}/"+btoa(vhc_id)+"?isChecked="+isChecked,
			type:'POST',
			dataType:'json',
			success:function(resp){
				// console.log(resp)
				if(resp.message)
				{
					alert(resp.message)
				}

			}
			});
	}
</script>

@stop