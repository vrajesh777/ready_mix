<!DOCTYPE html>
<html>
<head>
    <title>Ready Mix</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>
    <p>{{$details['doc_no']}}</p>
    <p>Name   : {{$details['name']}}</p>
    <p>Email  : {{ $details['email'] }}</p>
    <p>Mobile : {{ $details['mobile_no'] }}</p>
    <p>Thank you</p>
</body>
</html>