<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class VechicleRepairModel extends Model
{
    protected $table = 'vechicle_repair';
    protected $fillable = [
    						'repair_id',
    						'vechicle_id',
    						'make_id',
    						'model_id',
    						'year_id',
    						'chasis_no',
    						'regs_no',
    						'vin',
    						'note',
    						'date'
    					  ];
}
