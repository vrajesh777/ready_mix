				</div>
			</div>
		</div>
		<!-- /Main Wrapper -->

		<!-- Bootstrap Core JS -->
        <script src="<?php echo e(asset('/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>

		<!-- Custom JS -->
		<script src="<?php echo e(asset('/js/app.js')); ?>"></script>

		<script src="<?php echo e(asset('/js/jquery.validate.min.js')); ?>"></script>

    </body>
</html><?php /**PATH /home/cintvase/readymix.seeen.sa/resources/views/auth/_footer.blade.php ENDPATH**/ ?>