<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class VhcPartSupplyDetailModel extends Model
{
    protected $table = 'vhc_part_supply_detail';
    protected $fillable = [
    				'supply_order_id',
    				'make_id',
    				'model_id',
    				'year_id',
    				'part_id',
    				'quantity'
    			];
}
