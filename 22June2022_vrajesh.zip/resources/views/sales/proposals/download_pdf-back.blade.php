<?php
$grand_tot = 0;
?>
<!DOCTYPE html>

<html>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
<head>
	<title></title>
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
</head>
<style type="text/css">
	@media print {
	.alLeft{margin-left:5em}
	}
</style>
<body>

<table width="100%" border="0" align="left" cellpadding="0" cellspacing="0" style="padding-bottom:4px;font-size:11px; font-family:'Arial', sans-serif;">
	<tr>
		<td>
		<table width="100%" border="0" align="left" cellpadding="0" cellspacing="0" style="padding-bottom:4px;font-size:10px; font-family:'Arial', sans-serif;">
			<tr><td style="line-height:15px"><strong style=""># PRO-000002</strong></td></tr>
			<tr><td style="line-height:15px">Ankit Heights</td></tr>
			<tr><td style="line-height:15px">Date: 2021-01-14</td></tr>
			<tr><td style="line-height:15px">Open Till: 2021-02-12</td></tr>
				
			
		</table>	
		</td>
		<td>
		<table width="100%" border="0" align="right" cellpadding="0" cellspacing="0" style="padding-bottom:4px;font-size:10px; font-family:'Arial', sans-serif;">
			<tr><td style="line-height:15px"><strong style="">To</strong></td></tr>
			<tr><td style="line-height:15px"><strong style="">Ankit Joshi</strong></td></tr>
			<tr><td style="line-height:15px">Waluj MIDC</td></tr>
			<tr><td style="line-height:15px">Aurangabad Maharashtra IN</td></tr>
			<tr><td style="line-height:15px">ankitjoshi@mailinator.com</td></tr>
		</table>
		</td>
	</tr>
	<tr>
		    <td style="line-height:5px;">&nbsp;</td>
		  </tr>	
</table>

<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border:1px solid #ddd;font-size:10px; font-family:'Arial', sans-serif;">
		
		  <tr>
		      <th style="width:5%;background-color:#323a45;color:#fff;line-height:16px;height:22px;font-family:'Arial', sans-serif;">&nbsp;&nbsp;#</th>
		      <th style="width:34%;background-color:#323a45;color:#fff;line-height:16px;height:22px;font-family:'Arial', sans-serif;">Item</th>
		      <th style="width:11%;background-color:#323a45;color:#fff;line-height:16px;height:22px;">Qty</th>
		      <th style="background-color:#323a45;color:#fff;line-height:18px;height:22px;">Rate</th>
		      <th style="background-color:#323a45;color:#fff;line-height:18px;height:22px;">tax</th>
		      <th style="background-color:#323a45;color:#fff;line-height:18px;height:22px;">Amount</th>
		  </tr>

		  <tr><td style="line-height:5px;">&nbsp;</td></tr>

		  <tr>
		      <td style="font-size:11px;font-family:'Arial', sans-serif;">&nbsp;&nbsp;01</td>
		      <td class="alLeft" style="color:#444;font-family:'Arial', sans-serif;"><strong style="color:#000;">Cancrete M15</strong><br>Ready-Mix Concrete is concrete that is manufactured in a batch plant, according to a set engineered mix design. Ready-mix concrete is normally delivered in two ways. First is the barrel truck or in–transit mixers.
		      </td>
		      <td style="">53691</td>
		      <td style="">51.96</td>
		      <td style="">VAT 5.00%</td>
		      <td style="">115,588.00</td>
		  </tr>

		  <tr><td style="line-height:5px;">&nbsp;</td></tr>

		  <tr>
		      <td style="border-top:1px solid #ddd;line-height:20px;height:20px;" colspan="4"> </td>
		      <td style="border-top:1px solid #ddd;line-height:20px;height:20px;" colspan="1"><strong>Sub Total</strong></td>
		      <td style="border-top:1px solid #ddd;line-height:20px;height:20px;">$875.00</td>
		  </tr>
		  <tr>
		      <td colspan="4" style="line-height:20px;height:20px;"> </td>
		      <td colspan="1" style="line-height:20px;height:20px;"><strong>VAT (5.00%)</strong></td>
		      <td style="line-height:20px;height:20px;">$0.00</td>
		  </tr>
		  <tr>

		      <td colspan="4" style="line-height:20px;height:20px;background-color:#f0f0f0;">&nbsp;&nbsp;S.R. </td>
		      <td colspan="1" style="line-height:20px;height:20px;background-color:#f0f0f0;"><strong>Total</strong></td>
		      <td style="line-height:22px;height:22px;background-color:#f0f0f0;"><strong>$875.00</strong></td>
		  </tr>
		  
		 

		  
</table>

<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border:none;font-size:10px; font-family:'Arial', sans-serif;">
	 <tr><td style="line-height:50px;">&nbsp;</td></tr>
	<tr>
		      <td style="width:20%;line-height:20px;height:20px;">Authorized Signature</td>
		      <td style="width:30%;line-height:20px;height:20px;border-bottom:1px solid #ccc;"></td>
		      
		  </tr>
</table>	


</body>
</html>
