				</div>
			</div>
		</div>
		<!-- /Main Wrapper -->

		<!-- Bootstrap Core JS -->
        <script src="{{ asset('/js/popper.min.js') }}"></script>
        <script src="{{ asset('/js/bootstrap.min.js') }}"></script>

		<!-- Custom JS -->
		<script src="{{ asset('/js/app.js') }}"></script>

		<script src="{{ asset('/js/jquery.validate.min.js') }}"></script>

    </body>
</html>