<!-- HEader -->
@include('auth._header')

@yield('auth_main_content')

@include('auth._footer')