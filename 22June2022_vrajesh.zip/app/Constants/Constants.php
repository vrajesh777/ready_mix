<?php

define('PDF_MARGIN_TOP', 5);
define('PDF_MARGIN_LEFT', 2);
define('PDF_MARGIN_RIGHT', 5);
//product constant
define('CEMENT_TYPE',array('OPC', 'SRC', 'PPC','OTHERS'));
define('SLAMP',array('125±25','125±25','150±25','175±25','OTHERS'));
define('AIR_CONTENT',array('1.5%', '1.99%','OTHERS'));
define('NOT_A_MIXER_DRIVER',array(11,18,22,35,37,39,40,46,50,60,63,82,85,95,107,117,118,123));